
#ifndef GLIMG_H
#define GLIMG_H

#include <QtWidgets>
#include <QtOpenGL>

class GLImg : public QGLWidget
{
    Q_OBJECT
public:
    enum ProjectionType {OXY = 0, OXZ, OYZ};
    explicit GLImg(QWidget *parent = nullptr);
    void keyEvent(QKeyEvent* ev);
    void draw_xy_projection();
    void draw_xz_projection();
    void draw_zy_projection();
    void draw_scaling(float x, float y, float z);
    void draw_transfer(int x, int y, int z);
    void draw_rotation_x(int angle, float (&matrix)[3][3]);
    void draw_rotation_y(int angle, float (&matrix)[3][3]);
    void draw_rotation_z(int angle, float (&matrix)[3][3]);
    bool isLetterVisible;
    bool isProjSelected;
    ProjectionType prType;

private:
    GLfloat xMRot = 0;
    GLfloat yMRot = 0;
    GLfloat nSca;
    int x_transfer = 0;
    int y_transfer = 0;
    int z_transfer = 0;
    QPoint mousePos;
    QColor colour;

    void zoomIn();
    void zoomOut();

    void drawAxis();

    void drawFigure();

    void mousePressEvent(QMouseEvent *ev) override;
    void mouseMoveEvent(QMouseEvent *ev) override;
    void wheelEvent(QWheelEvent* ev) override;
    void keyPressEvent(QKeyEvent* ev) override;
    void initializeGL() override;
    void resizeGL(int w, int h) override;
    void paintGL() override;

};

#endif // GLIMG_H
