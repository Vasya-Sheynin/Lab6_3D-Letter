
#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    setWindowTitle("3D Letter");
    setLayout(ui->gridLayout_3);

    ui->tableWidget->horizontalHeader()->setVisible(false);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->tableWidget_2->horizontalHeader()->setVisible(false);
    ui->tableWidget_2->verticalHeader()->setVisible(false);
    ui->tableWidget_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_2->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_2->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->tableWidget_3->horizontalHeader()->setVisible(false);
    ui->tableWidget_3->verticalHeader()->setVisible(false);
    ui->tableWidget_3->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_3->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_3->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->tableWidget_4->horizontalHeader()->setVisible(false);
    ui->tableWidget_4->verticalHeader()->setVisible(false);
    ui->tableWidget_4->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_4->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_4->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->tableWidget_5->horizontalHeader()->setVisible(false);
    ui->tableWidget_5->verticalHeader()->setVisible(false);
    ui->tableWidget_5->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_5->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_5->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->tableWidget_6->horizontalHeader()->setVisible(false);
    ui->tableWidget_6->verticalHeader()->setVisible(false);
    ui->tableWidget_6->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_6->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget_6->setEditTriggers(QAbstractItemView::NoEditTriggers);

    connect(ui->pushButton_4, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->draw_transfer(ui->spinBox->value(), ui->spinBox_2->value(), ui->spinBox_3->value());
        ui->tableWidget_2->item(0, 3)->setText(QString::number(ui->spinBox->value()));
        ui->tableWidget_2->item(1, 3)->setText(QString::number(ui->spinBox_2->value()));
        ui->tableWidget_2->item(2, 3)->setText(QString::number(ui->spinBox_3->value()));

        ui->spinBox->setValue(0);
        ui->spinBox_2->setValue(0);
        ui->spinBox_3->setValue(0);

        ((GLImg*)ui->widget)->updateGL();
    });

    connect(ui->pushButton_5, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->draw_scaling(ui->spinBox_4->value(), ui->spinBox_5->value(), ui->spinBox_6->value());
        ui->tableWidget->item(0, 0)->setText(QString::number(ui->spinBox_4->value()));
        ui->tableWidget->item(1, 1)->setText(QString::number(ui->spinBox_5->value()));
        ui->tableWidget->item(2, 2)->setText(QString::number(ui->spinBox_6->value()));

        ui->spinBox_4->setValue(1);
        ui->spinBox_5->setValue(1);
        ui->spinBox_6->setValue(1);

        ((GLImg*)ui->widget)->updateGL();
    });

    connect(ui->pushButton_6, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->draw_scaling(1.0 / ui->spinBox_4->value(), 1.0 / ui->spinBox_5->value(), 1.0 / ui->spinBox_6->value());
        ui->tableWidget->item(0, 0)->setText(QString::number(1.0 / ui->spinBox_4->value()));
        ui->tableWidget->item(1, 1)->setText(QString::number(1.0 / ui->spinBox_5->value()));
        ui->tableWidget->item(2, 2)->setText(QString::number(1.0 / ui->spinBox_6->value()));

        ui->spinBox_4->setValue(1);
        ui->spinBox_5->setValue(1);
        ui->spinBox_6->setValue(1);

        ((GLImg*)ui->widget)->updateGL();
    });

    connect(ui->pushButton_7, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->draw_rotation_x(ui->spinBox_7->value(), xMatrix);
        ((GLImg*)ui->widget)->draw_rotation_y(ui->spinBox_8->value(), yMatrix);
        ((GLImg*)ui->widget)->draw_rotation_z(ui->spinBox_9->value(), zMatrix);

        ui->spinBox_7->setValue(0);
        ui->spinBox_8->setValue(0);
        ui->spinBox_9->setValue(0);

        float bufMatrix[3][3];
        float buf2Matrix[3][3];

        multiplyMatrix(zMatrix, yMatrix, bufMatrix);
        multiplyMatrix(bufMatrix, xMatrix, buf2Matrix);

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                ui->tableWidget_3->item(i, j)->setText(QString::number(buf2Matrix[i][j]));
            }
        }

        ((GLImg*)ui->widget)->updateGL();
    });

    connect(ui->pushButton, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->isLetterVisible = false;
        ((GLImg*)ui->widget)->isProjSelected = true;
        ((GLImg*)ui->widget)->prType = ((GLImg)ui->widget).ProjectionType::OXY;
        ((GLImg*)ui->widget)->updateGL();
        ui->tableWidget_4->item(2, 2)->setText("0");
    });

    connect(ui->pushButton_2, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->isLetterVisible = false;
        ((GLImg*)ui->widget)->isProjSelected = true;
        ((GLImg*)ui->widget)->prType = ((GLImg)ui->widget).ProjectionType::OXZ;
        ((GLImg*)ui->widget)->updateGL();
        ui->tableWidget_5->item(1, 1)->setText("0");
    });

    connect(ui->pushButton_3, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->isLetterVisible = false;
        ((GLImg*)ui->widget)->isProjSelected = true;
        ((GLImg*)ui->widget)->prType = ((GLImg)ui->widget).ProjectionType::OYZ;
        ((GLImg*)ui->widget)->updateGL();
        ui->tableWidget_6->item(0, 0)->setText("0");
    });

    connect(ui->pushButton_8, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->isLetterVisible = true;
        ((GLImg*)ui->widget)->isProjSelected = false;
        ((GLImg*)ui->widget)->updateGL();
    });

    connect(ui->pushButton_9, &QPushButton::clicked, ui->widget, [=](){
        ((GLImg*)ui->widget)->isLetterVisible = false;
        ((GLImg*)ui->widget)->updateGL();
    });
}

Widget::~Widget()
{
    delete ui;
}

void Widget::keyPressEvent(QKeyEvent *ev)
{
    ((GLImg*)ui->widget)->keyEvent(ev);
}

void Widget::multiplyMatrix(float m1[3][3], float m2[3][3], float (&bufMatrix)[3][3])
{
    for (int i = 0; i < 3; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            bufMatrix[i][j] = 0;

            for (int k = 0; k < 3; ++k)
            {
                bufMatrix[i][j] += m1[i][k] * m2[k][j];
            }
        }
    }
}


