
#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>



QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget

{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Ui::Widget *ui;
    void keyPressEvent(QKeyEvent* ev) override;
    void multiplyMatrix(float m1[3][3], float m2[3][3], float (&bufMatrix)[3][3]);

    float xMatrix[3][3];
    float yMatrix[3][3];
    float zMatrix[3][3];
};

#endif // WIDGET_H
