#include "glimg.h"

GLfloat VertexArray[64][3] = {
    {0, 0, 0},
    {1, 0, 0},
    {2, 0, 0},
    {3, 0, 0},
    {4, 0, 0},
    {5, 0, 0},
    {0, 4, 0},
    {1, 4, 0},
    {2, 4, 0},
    {3, 4, 0},
    {4, 4, 0},
    {5, 4, 0},
    {0, 1, 0},
    {5, 1, 0},
    {0, 0, 1},
    {1, 0, 1},
    {2, 0, 1},
    {3, 0, 1},
    {4, 0, 1},
    {5, 0, 1},
    {0, 4, 1},
    {1, 4, 1},
    {2, 4, 1},
    {3, 4, 1},
    {4, 4, 1},
    {5, 4, 1},
    {0, 1, 1},
    {5, 1, 1}
};

GLubyte IndexArray[18][4] = {
    {0, 1, 7, 6},
    {2, 3, 9, 8},
    {4, 5, 11, 10},
    {0, 12, 13, 5},

    {14, 15, 21, 20},
    {16, 17, 23, 22},
    {18, 19, 25, 24},
    {14, 26, 27, 19},

    {0, 6, 20, 14},
    {1, 7, 21, 15},
    {2, 8, 22, 16},
    {3, 9, 23, 17},
    {4, 10, 24, 18},
    {5, 11, 25, 19},

    {0, 5, 19, 14},
    {6, 7, 21, 20},
    {8, 9, 23, 22},
    {10, 11, 25, 24}
};

GLImg::GLImg(QWidget *parent)
    : QGLWidget(parent)
{
    setGeometry(400, 200, 800, 600);

    nSca = 1;
    isLetterVisible = true;
    isProjSelected = false;
}

void GLImg::keyEvent(QKeyEvent *ev)
{
    keyPressEvent(ev);
}

void GLImg::initializeGL()
{
    qglClearColor(Qt::white);
    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_FLAT);
}

void GLImg::resizeGL(int nWidth, int nHeight)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    GLfloat ratio=(GLfloat)nHeight/(GLfloat)nWidth;

    if (nWidth>=nHeight)
    {
        glOrtho(-1.0 / ratio, 1.0 / ratio, -1.0, 1.0, -5.0, 5.0);
    }
    else
    {
        glOrtho(-1.0, 1.0, -1.0 * ratio, 1.0 * ratio, -5.0, 5.0);
    }

    glViewport(0, 0, (GLint)nWidth, (GLint)nHeight);
}

void GLImg::paintGL()
{
    glClearColor(1,1,1,0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glScalef(nSca, nSca, nSca);

    glRotatef(xMRot, 1.0f, 0.0f, 0.0f);
    glRotatef(yMRot, 0.0f, 1.0f, 0.0f);

    drawAxis();

    double r1 = 0, g1 = 0, b1 = 0;
    colour.getRgbF(&r1, &g1, &b1, nullptr);
    glColor4f(r1, g1, b1, 0.0f);

    QFont tmpfont;
    tmpfont.setFamily("Arial Black");
    tmpfont.setPointSize(10);
    tmpfont.setBold(false);
    glColor3f(0,0,0);
    renderText(10,0.0,0.0,"X",tmpfont);
    glColor3f(0,0,0);
    renderText(0.0,10,0.0,"Y",tmpfont);
    glColor3f(0,0,0);
    renderText(0.0,0.0,10,"Z",tmpfont);

    if (isLetterVisible)
    {
        drawFigure();
    }
    else
    {
        if (isProjSelected)
        {
            switch (prType)
            {
            case ProjectionType::OXY:
            {
                draw_xy_projection();
                break;
            }
            case ProjectionType::OXZ:
            {
                draw_xz_projection();
                break;
            }
            case ProjectionType::OYZ:
            {
                draw_zy_projection();
                break;
            }
            }
        }
    }
}

void GLImg::mousePressEvent(QMouseEvent* ev)
{
    if (ev->buttons() == Qt::LeftButton)
    {
        mousePos = ev->pos();
    }
}

void GLImg::mouseMoveEvent(QMouseEvent* ev)
{
    if (ev->buttons() == Qt::LeftButton)
    {
        xMRot += 1.0 / M_PI * (GLfloat)(ev->y() - mousePos.y());
        yMRot += 1.0 / M_PI * (GLfloat)(ev->x() - mousePos.x());

        xMRot = std::fmod(xMRot, 360.0);
        yMRot = std::fmod(yMRot, 360.0);

        mousePos = ev->pos();

        updateGL();
    }
}

void GLImg::wheelEvent(QWheelEvent* ev)
{
    if (ev->delta() > 0)
    {
        zoomIn();
    }
    else
    {
        if (ev->delta() < 0)
        {
            zoomOut();
        }
    }

    updateGL();
}

void GLImg::keyPressEvent(QKeyEvent* pe)
{
    switch (pe->key())
    {
    case Qt::Key_Plus:
        zoomIn();
        break;

    case Qt::Key_Minus:
        zoomOut();
        break;

    default:
        break;
    }

    updateGL();
}


void GLImg::zoomIn()
{
    nSca *= 1.1;
}

void GLImg::zoomOut()
{
    nSca /= 1.1;
}

void GLImg::drawAxis()
{
    glLineWidth(3.0f);

    glColor4f(1.00f, 0.00f, 0.00f, 1.0f);
    glBegin(GL_LINES);
    glVertex3f( 10.0f,  0.0f,  0.0f);
    glVertex3f(-10.0f,  0.0f,  0.0f);
    glEnd();

    glColor4f(0.00f, 1.00f, 0.00f, 1.0f);
    glBegin(GL_LINES);
    glVertex3f( 0.0f,  10.0f,  0.0f);
    glVertex3f( 0.0f, -10.0f,  0.0f);
    glEnd();

    glColor4f(0.00f, 0.00f, 1.00f, 1.0f);
    glBegin(GL_LINES);
    glVertex3f( 0.0f,  0.0f,  10.0f);
    glVertex3f( 0.0f,  0.0f, -10.0f);
    glEnd();

    glColor4f(0.00f, 0.00f, 0.00f, 0.0f);
    for (float i = -10; i < 10; i += 0.25){
        float k = 20.0;
        glBegin(GL_LINES);
        glVertex3f(i, -1.0 / k, 0.0f);
        glVertex3f(i, 1.0 / k, 0.0f);
        glVertex3f(-1.0 / k, i, 0.0f);
        glVertex3f(1.0 / k, i, 0.0f);
        glVertex3f( 0.0f, 1.0 / k, i);
        glVertex3f( 0.0f, -1.0 / k, i);
        glEnd();
    }

}

void GLImg::draw_rotation_z(int angle, float (&matrix)[3][3])
{
    matrix[0][0] = cos(angle * M_PI / 180.0);
    matrix[0][1] = -sin(angle * M_PI / 180.0);
    matrix[0][2] = 0;

    matrix[1][0] = sin(angle * (M_PI / 180.0));
    matrix[1][1] = cos(angle * (M_PI / 180.0));
    matrix[1][2] = 0;

    matrix[2][0] = 0;
    matrix[2][1] = 0;
    matrix[2][2] = 1;

    for (int k = 0; k < 64; k++)
    {
        float tmp[3] = {0, 0, 0};

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                tmp[i] += VertexArray[k][j] * matrix[i][j];
            }
        }

        for (int i = 0; i < 3; i++)
        {
            VertexArray[k][i] = tmp[i];
        }
    }

    drawFigure();
}

void GLImg::draw_rotation_y(int angle, float (&matrix)[3][3])
{
    matrix[0][0] = cos(angle * M_PI / 180.0);
    matrix[0][1] = 0;
    matrix[0][2] = sin(angle * M_PI / 180.0);

    matrix[1][0] = 0;
    matrix[1][1] = 1;
    matrix[1][2] = 0;

    matrix[2][0] = -sin(angle * (M_PI / 180.0));
    matrix[2][1] = 0;
    matrix[2][2] = cos(angle * (M_PI / 180.0));

    for (int k = 0; k < 64; k++)
    {
        float tmp[3] = {0, 0, 0};

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                tmp[i] += VertexArray[k][j] * matrix[i][j];
            }
        }

        for (int i = 0; i < 3; i++)
        {
            VertexArray[k][i] = tmp[i];
        }
    }

    drawFigure();
}

void GLImg::draw_rotation_x(int angle, float (&matrix)[3][3])
{
    matrix[0][0] = 1;
    matrix[0][1] = 0;
    matrix[0][2] = 0;

    matrix[1][0] = 0;
    matrix[1][1] = cos(angle * M_PI / 180.0);
    matrix[1][2] = -sin(angle * M_PI / 180.0);

    matrix[2][0] = 0;
    matrix[2][1] = sin(angle * (M_PI / 180.0));
    matrix[2][2] = cos(angle * (M_PI / 180.0));

    for (int k = 0; k < 64; k++)
    {
        float tmp[3] = {0, 0, 0};

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                tmp[i] += VertexArray[k][j] * matrix[i][j];
            }
        }

        for (int i = 0; i < 3; i++)
        {
            VertexArray[k][i] = tmp[i];
        }
    }

    drawFigure();
}

void GLImg::draw_transfer(int dx, int dy, int dz)
{
    for(int i = 0; i < 64; i++)
    {
        VertexArray[i][0] += -x_transfer + dx;
        VertexArray[i][1] += -y_transfer + dy;
        VertexArray[i][2] += -z_transfer + dz;
    }

    x_transfer = dx;
    y_transfer = dy;
    z_transfer = dz;

    drawFigure();
}

void GLImg::draw_scaling(float dx, float dy, float dz)
{
    for (int i = 0; i < 64; i++)
    {
        VertexArray[i][0] = (VertexArray[i][0] - x_transfer) * dx + x_transfer;
        VertexArray[i][1] = (VertexArray[i][1] - y_transfer) * dy + y_transfer;
        VertexArray[i][2] = (VertexArray[i][2] - z_transfer) * dz + z_transfer;
    }

    drawFigure();
}

void GLImg::draw_xy_projection()
{

    GLfloat c[72][3];
    GLfloat conv[3][3] ;
    conv[0][0] = 1;
    conv[0][1] = 0;
    conv[0][2] = 0;

    conv[1][0] = 0;
    conv[1][1] = 1;
    conv[1][2] = 0;

    conv[2][0] = 0;
    conv[2][1] = 0;
    conv[2][2] = 0;
    for(int i = 0; i < 72; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            c[i][j] = 0;

            for(int k = 0; k < 3; k++)
            {
                c[i][j] += VertexArray[i][k] * conv[k][j];
            }
        }
    }

    glVertexPointer(3, GL_FLOAT, 0, c);
    glEnableClientState(GL_VERTEX_ARRAY);
    glDrawElements(GL_QUADS, 72, GL_UNSIGNED_BYTE, IndexArray);
    glDisableClientState(GL_VERTEX_ARRAY);
}

void GLImg::draw_xz_projection()
{

    GLfloat c[72][3];
    GLfloat conv[3][3] ;
    conv[0][0] = 1;
    conv[0][1] = 0;
    conv[0][2] = 0;

    conv[1][0] = 0;
    conv[1][1] = 0;
    conv[1][2] = 0;

    conv[2][0] = 0;
    conv[2][1] = 0;
    conv[2][2] = 1;
    for(int i = 0; i < 72; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            c[i][j] = 0;
            for(int k = 0; k < 3; k++)
            {
                c[i][j] += VertexArray[i][k] * conv[k][j];
            }
        }
    }
    glVertexPointer(3, GL_FLOAT, 0, c);
    glEnableClientState(GL_VERTEX_ARRAY);
    glDrawElements(GL_QUADS, 72, GL_UNSIGNED_BYTE, IndexArray);
    glDisableClientState(GL_VERTEX_ARRAY);
}

void GLImg::draw_zy_projection()
{
    GLfloat c[72][3];
    GLfloat conv[3][3] ;
    conv[0][0] = 0;
    conv[0][1] = 0;
    conv[0][2] = 0;

    conv[1][0] = 0;
    conv[1][1] = 1;
    conv[1][2] = 0;

    conv[2][0] = 0;
    conv[2][1] = 0;
    conv[2][2] = 1;
    for(int i = 0; i < 72; i++)
    {
        for(int j = 0; j < 3; j++)
        {
            c[i][j] = 0;
            for(int k = 0; k < 3; k++)
            {
                c[i][j] += VertexArray[i][k] * conv[k][j];
            }
        }
    }

    glVertexPointer(3, GL_FLOAT, 0, c);
    glEnableClientState(GL_VERTEX_ARRAY);
    glDrawElements(GL_QUADS, 72, GL_UNSIGNED_BYTE, IndexArray);
    glDisableClientState(GL_VERTEX_ARRAY);
}

void GLImg::drawFigure(){
    glVertexPointer(3, GL_FLOAT, 0, VertexArray);
    glEnableClientState(GL_VERTEX_ARRAY);
    glDrawElements(GL_QUADS, 72, GL_UNSIGNED_BYTE, IndexArray);
    glDisableClientState(GL_VERTEX_ARRAY);
}
